/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package cse.maven_webmail.model;

import cse.maven_webmail.control.CommandType;
import java.util.ArrayList;
import javax.mail.Message;

/**
 *
 * @author jongmin
 */
// 메시지 목록이나 메시지의 내용을 웹 화면에 보일 수 있도록 HTML <TABLE> 요소를 이용해 표 형태로
// 만들어 준다. 이 때 HTML <TABLE> 요소에 들어갈 메시지 헤더 정보를 추출하는 책임을 MessageParser 클래스가 담당한다. 
public class MessageFormatter {

    private String userid;  // 파일 임시 저장 디렉토리 생성에 필요

    public MessageFormatter(String userid) {
        this.userid = userid;
    }

    public String getMessageTable(Message[] messages) {
        StringBuilder buffer = new StringBuilder();

        // 메시지 제목 보여주기
        buffer.append("<table>");  // table start
        buffer.append("<tr> "
                + " <th> No. </td> "
                + " <th> 보낸 사람 </td>"
                + " <th> 제목 </td>     "
                + " <th> 송신자 </td>"
                + " <th> 보낸 날짜 </td>   "
                + " <th> 삭제 </td>   "
                //+ " <th> 스팸 </td"
                + " </tr>");
        
        
        for (int i = messages.length - 1; i >= 0; i--) {
            MessageParser parser = new MessageParser(messages[i], userid);
            parser.parse(false);  // envelope 정보만 필요
            // 메시지 헤더 포맷
            // 추출한 정보를 출력 포맷 사용하여 스트링으로 만들기
            
   
            int idx = parser.getToAddress().indexOf("@");  // parser.getToAddress() == "lee@127.0.0.1", parser.getToAddress().indexOf("@) == "lee"
            if(!parser.getFromAddress().substring(0,idx).equals(userid)){ 
                    buffer.append("<tr> "
                    + " <td id=no>" + (i+1) + " </td> "
                    + " <td id=sender>" + parser.getFromAddress() + "</td>" // 보낸 사람
                    + " <td id=sender> " // <td id=subject로 하면 너무 큰 비중 차지 
                    + " <a href=show_message.jsp?msgid=" + (i+1) + " title=\"메일 보기\"> "
                    + parser.getSubject() + "</a> </td>"
                            // 내가 추가한 것(아래)
                            + " <td id=sender> "  // <td id=sender_name 이 맞음
                            + " <a href=show_message.jsp?msgid=" + (i+1) + " title=\"메일 보기\"> "
                            + parser.getCcAddress()+ "</td>" // 송신자 이름                                    
                    + " <td id=date>" + parser.getSentDate() + "</td>"
                    + " <td id=delete>"
                    + "<a href=ReadMail.do?menu="
                    + CommandType.DELETE_MAIL_COMMAND
                    + "&msgid=" + (i+1) + "> 삭제 </a>" + "</td>"
                            // 추가한 것
                            //+ "<td id=delete>" // td id=spam으로 고쳐야함
                            //+ "<a href=WriteMail.do?menu="
                            //+ CommandType.ADD_SPAM
                            //+ CommandType.DELETE_MAIL_COMMAND
                            //+ "&msgid=" + (i+1) + "> 스팸 </a>" + "</td>"
                    + " </tr>");
            }
        }
        buffer.append("</table>");
        

        return buffer.toString();
//        return "MessageFormatter 테이블 결과";
    }
    
    

    public String getMessage(Message message) {
        StringBuilder buffer = new StringBuilder();

        MessageParser parser = new MessageParser(message, userid);
        parser.parse(true);

        buffer.append("보낸 사람 : " + parser.getFromAddress() + " <br>");
        buffer.append("송  신  자 &nbsp : " + parser.getCcAddress() + "<br>");
        buffer.append("받은 사람 : " + parser.getToAddress() + " <br>");
        buffer.append("CC &nbsp&nbsp;&nbsp;&nbsp;&nbsp;&nbsp&nbsp&nbsp : " + parser.getCcAddress() + " <br>");
        buffer.append("보낸 날짜 : " + parser.getSentDate() + " <br>");
        buffer.append("제 &nbsp;&nbsp;&nbsp&nbsp&nbsp;  목 : " + parser.getSubject() + " <br> <hr>");
        
      
        buffer.append(parser.getBody());

        String attachedFile = parser.getFileName();
        if (attachedFile != null) {
            buffer.append("<br> <hr> 첨부파일: <a href=ReadMail.do?menu="
                    + CommandType.DOWNLOAD_COMMAND
                    + "&userid=" + this.userid
                    + "&filename=" + attachedFile.replaceAll(" ", "%20")
                    + " target=_top> " + attachedFile + "</a> <br>");
        }

        return buffer.toString();
    }
    
    // 내게 쓴 메일함 
    public String getSelfSentMessageTable(Message[] messages) {
        StringBuilder buffer = new StringBuilder();
     
        buffer.append("<table>");  // table start
        buffer.append("<tr> "
                + " <th> No. </td> "
                //+ " <th> 받은 사람 </td>"
                + " <th> 제목 </td>     "
                //+ " <th> 송신자 </td>"
                + " <th> 보낸 날짜 </td>   "
                + " <th> 삭제 </td>   "
                + " </tr>");
        
        int k=0; // 내게 쓴 메일함 읽기 리스트 순서
        for (int i = messages.length - 1; i >= 0; i--) {
            
            MessageParser parser = new MessageParser(messages[i], userid);
            parser.parse(false);  // envelope 정보만 필요
            // 메시지 헤더 포맷
            // 추출한 정보를 출력 포맷 사용하여 스트링으로 만들기
            
            
            int idx = parser.getToAddress().indexOf("@");  // parser.getToAddress() == "lee@127.0.0.1", parser.getToAddress().indexOf("@) == "lee"
            if(parser.getFromAddress().substring(0,idx).equals(userid)){ // 송신자가 userid와 같으면
                  k++; // 리스트 넘버 증가

                    buffer.append("<tr> "                    
                    + " <td id=no>" + (k) + " </td> "   
                    //+" <td id=sender>" + parser.getFromAddress() + "</td>" // 받은 사람으로 해야함
                    + " <td id=subject> "
                    + " <a href=show_message.jsp?msgid=" + (i+1) + " title=\"메일 보기\"> "
                    + parser.getSubject() + "</a> </td>"
                            // 내가 추가한 것(아래)
                            //+ " <td id=sender_name> " 
                            //+ parser.getCcAddress()+ "</td>" // 송신자 이름                                    
                    + " <td id=date>" + parser.getSentDate() + "</td>"
                    + " <td id=delete>"
                    + "<a href=ReadMail.do?menu="
                    + CommandType.DELETE_MAIL_COMMAND
                    + "&msgid=" + (i+1) + "> 삭제 </a>" + "</td>"
                    + " </tr>");
            }
        }
        buffer.append("</table>");

        return buffer.toString();
//        return "MessageFormatter 테이블 결과";
    }
    
    // 보낸 메일함 관련
    public String getSentMessageTable(Message[] messages) {
        StringBuilder buffer = new StringBuilder();

        // 메시지 제목 보여주기
        buffer.append("<table>");  // table start
        buffer.append("<tr> "
                + " <th> No. </td> "
                + " <th> 수신인 </td>"
                + " <th> 제목 </td>     "
                //+ " <th> 송신자 </td>"
                + " <th> 보낸 날짜 </td>   "
                + " <th> 삭제 </td>   "
                + " </tr>");
        
        
        for (int i = messages.length - 1; i >= 0; i--) {
            MessageParser parser = new MessageParser(messages[i], userid);
            parser.parse(false);  // envelope 정보만 필요
            // 메시지 헤더 포맷
            // 추출한 정보를 출력 포맷 사용하여 스트링으로 만들기
            
   
            int idx = parser.getToAddress().indexOf("@");  // parser.getToAddress() == "lee@127.0.0.1", parser.getToAddress().indexOf("@) == "lee"
            int idx2 = parser.getFromAddress().indexOf("@");
            //if(!parser.getFromAddress().equals(parser.getToAddress())){ 
                    buffer.append("<tr> "
                    + " <td id=no>" + (i+1) + " </td> "
                    + " <td id=sender>" + parser.getToAddress() + "</td>" 
                            
                    + " <td id=ssubject> "
                    + " <a href=show_message.jsp?msgid=" + (i+1) + " title=\"메일 보기\"> "
                    + parser.getSubject() + "</a> </td>"
                            // 내가 추가한 것(아래)
                            //+ " <td id=sender_name> " 
                            //+ " <a href=show_message.jsp?msgid=" + (i+1) + " title=\"메일 보기\"> "
                            //+ parser.getCcAddress()+ "</td>" // 송신자 이름                                    
                    + " <td id=date>" + parser.getSentDate() + "</td>"
                    + " <td id=delete>"
                    + "<a href=ReadMail.do?menu="
                    + CommandType.DELETE_MAIL_COMMAND
                    + "&msgid=" + (i+1) + "> 삭제 </a>" + "</td>"
                    + " </tr>");
            //}
        }
        buffer.append("</table>");
        

        return buffer.toString();
//        return "MessageFormatter 테이블 결과";
    }
    
    public String getSpamMessageTable(Message[] messages) {
        StringBuilder buffer = new StringBuilder();
     
        buffer.append("<table>");  // table start
        buffer.append("<tr> "
                + " <th> No. </td> "
                //+ " <th> 받은 사람 </td>"
                + " <th> 제목 </td>     "
                //+ " <th> 송신자 </td>"
                + " <th> 보낸 날짜 </td>   "
                + " <th> 삭제 </td>   "
                + " </tr>");
        
        int k=0; // 내게 쓴 메일함 읽기 리스트 순서
        for (int i = messages.length - 1; i >= 0; i--) {
            
            MessageParser parser = new MessageParser(messages[i], userid);
            parser.parse(false);  // envelope 정보만 필요
            // 메시지 헤더 포맷
            // 추출한 정보를 출력 포맷 사용하여 스트링으로 만들기
            
            
            int idx = parser.getToAddress().indexOf("@");  // parser.getToAddress() == "lee@127.0.0.1", parser.getToAddress().indexOf("@) == "lee"
            if(parser.getFromAddress().substring(0,idx).equals(userid)){ // 송신자가 userid와 같으면
                  k++; // 리스트 넘버 증가

                    buffer.append("<tr> "                    
                    + " <td id=no>" + (k) + " </td> "   
                    //+" <td id=sender>" + parser.getFromAddress() + "</td>" // 받은 사람으로 해야함
                    + " <td id=subject> "
                    + " <a href=show_message.jsp?msgid=" + (i+1) + " title=\"메일 보기\"> "
                    + parser.getSubject() + "</a> </td>"
                            // 내가 추가한 것(아래)
                            //+ " <td id=sender_name> " 
                            //+ parser.getCcAddress()+ "</td>" // 송신자 이름                                    
                    + " <td id=date>" + parser.getSentDate() + "</td>"
                    + " <td id=delete>"
                    + "<a href=ReadMail.do?menu="
                    + CommandType.DELETE_MAIL_COMMAND
                    + "&msgid=" + (i+1) + "> 삭제 </a>" + "</td>"
                    + " </tr>");
            }
        }
        buffer.append("</table>");

        return buffer.toString();
//        return "MessageFormatter 테이블 결과";
    }
    
    // 내가 추가한 것 (답장 시 자동적으로 제목이 결정 되게 하는 것)
    public String getSubject(Message message){
        StringBuilder buffer = new StringBuilder();

        MessageParser parser = new MessageParser(message, userid);
        parser.parse(true);

        buffer.append(parser.getSubject());

        return buffer.toString();
    }
    
    // 내가 추가한 것 (답장 시 자동적으로 송신자가 결정 되게 하는 것)
    public String getFromAddress(Message message){
        StringBuilder buffer = new StringBuilder();

        MessageParser parser = new MessageParser(message, userid);
        parser.parse(true);

        buffer.append(parser.getFromAddress());

        return buffer.toString();
    }
    

    // 내가 추가한 것 (본문 내용은 왜 안되지?)
    public String getBody(Message message){
        StringBuilder buffer = new StringBuilder();

        MessageParser parser = new MessageParser(message, userid);
        parser.parse(true);

        buffer.append(parser.getBody());

        return buffer.toString();
    }
}
